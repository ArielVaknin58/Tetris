**Exercise 1 - Tetris Program**
Programmers Names:
Ariel Vaknin - ID: 209478791
Yaron Miroluz - ID: 207896028

We implemented both the Colors bonus and the Score bonus.