#include <iostream>
#include <string>
#include "Game.h"
#include "Player.h"
#include "shapes.h"
#include <conio.h>
#include <windows.h> 
#include "MainFunctions.h"
using namespace std;

int main()
{
    Game launch;
    launch.MainGame();

    return 0;
}

