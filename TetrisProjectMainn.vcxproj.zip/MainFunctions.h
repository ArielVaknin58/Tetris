#pragma once

//General Utility Functions
bool askForColors();
int PrintInitialMainMenu();
int PrintPausedMainMenu();
int PrintInstructionsAndKeys();
void Gotoxy(int x,int y);
void Swap(short& x, short& y);
void Swap(int& x, int& y);

